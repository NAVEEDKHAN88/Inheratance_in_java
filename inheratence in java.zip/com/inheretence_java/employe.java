package com.inheretence_java;
 class employe {

	float salary = 40000;

}


