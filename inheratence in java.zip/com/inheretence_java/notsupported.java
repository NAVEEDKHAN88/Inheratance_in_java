package com.inheretence_java;

class A {
	void msg() {
		System.out.println("Hello");
	}
}

class B {
	void msg() {
		System.out.println("Welcome");
	}
}

public class notsupported {

	public static void main(String args[]) {
		C obj = new C();
		obj.msg();// Now which msg() method would be invoked?
	}
}