package com.inheretence_java;

 class owner extends employe{
	 int bonus=10000;
	 public static void main(String args[]){
	   owner p=new owner();
	   System.out.println("Programmer salary is:"+p.salary);
	   System.out.println("Bonus of empioye is:"+p.bonus);
	}
}
