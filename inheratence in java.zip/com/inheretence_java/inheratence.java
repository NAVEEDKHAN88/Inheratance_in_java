package com.inheretence_java;


// multi level inheritance problem


 class Animal {
	public void eat() {
		System.out.println("eating");
	}

}

 class dog extends  Animal {
	public void bark() {
		System.out.println("barking");
	}
}

class babydog extends dog{
	public void weep() {
		System.out.println("weeping");
	}
} 

public class inheratence{
	public static void main(String args[]) {
		babydog m=new babydog();
		
		m.eat();
		m.bark();
		m.weep();
	}
}