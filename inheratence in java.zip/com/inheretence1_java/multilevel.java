package com.inheretence1_java;

// multilevel problem

class breed {
	public void eat() {
		System.out.println("eating......");
	}
}

class sheep extends breed {
	public void baaah() {
		System.out.println("baaaaaah.....");
	}
}

class frog extends breed {
	public void ribbet() {
		System.out.println("ribbit....");
	}
}

public class multilevel {
	public static void main(String args[]) {
		sheep s = new sheep();

		s.baaah();
		s.eat();
		frog n=new frog();
		n.ribbet();
	}
}
